Drop your Dialogue characters shit here

If you're asking "How do i make dialogues play?" or any other questions, read this:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Dialogues